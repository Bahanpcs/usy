import discord
import asyncio
import requests
import threading
import sys
import os
from typing import Optional
from colorama import Fore
import time
import random


def Clear():
    if sys.platform in ["linux", "linux2"]:
        os.system("clear")
    else:
        os.system("cls")


Clear()


def setTitle(title: Optional[any] = None):
    os.system(f"title {title}")


setTitle("Multiple Token Hoster - []")

session = requests.Session()
tokens = []
with open("tokens.txt", "r") as f:
    tokens_ = f.read().split("\n")

if len(tokens_) == 0:
    print(
        " | There Are No Tokens. Please Add Some Tokens To Host In the tokens.txt File."
    )
    exit()


def Check_Token(Token):
    response = requests.get(f"https://discord.com/api/v9/users/@me",
                            headers={"Authorization": Token})
    if response.status_code in [204, 200, 201]:
        print(f" | {Token} Is Valid.")
        tokens.append(Token)
    if "need to verify" in response.text:
        print(f" | {Token} Is On Verification.")
    elif response.status_code in [404, 401, 400]:
        print(f" | {Token} Invalid Token Or Rate Limited.")


for tk in tokens_:
    Check_Token(tk)

if len(tokens) == 0:
    print(" | All Tokens Were Invalid. Try Again Later With Working Tokens.")
    exit()

time.sleep(2)
Clear()
menu = f"""{Fore.RED}[-]{Fore.RESET} Created by \n"""

print(menu)

# List of random game names and activities
game_names = [
     ""  
]

loop = asyncio.get_event_loop()
for tk in tokens:
    # Generate random status and activity for each token
    random_status = random.choice(
        [discord.Status.dnd, discord.Status.idle, discord.Status.online])
    random_game = random.choice(game_names)
    random_activity = discord.Game(name=random_game)

    client = discord.Client(status=random_status, activity=random_activity)
    loop.create_task(client.start(tk, bot=False))
    print(" ")
    print(" | {} Is Hosted.\n".format(tk))

    async def change_status():
        while True:
            # Generate a random time in seconds up to 1 hour and 30 minutes
            random_time = random.randint(0, 5400)
            await asyncio.sleep(random_time)

            # Change the status and activity
            random_status = random.choice([
                discord.Status.dnd, discord.Status.idle, discord.Status.online
            ])
            random_game = random.choice(game_names)
            random_activity = discord.Game(name=random_game)

            await client.change_presence(status=random_status,
                                         activity=random_activity)

    loop.create_task(change_status())

threading.Thread(target=loop.run_forever).start()

while True:
    idk = 0
    idk += 1
